# Testing Apps

## Unit Testing & Integration Testing
you can start testing script
```
npm test
```

## Coverage Test
you can start test coverage
```
npm run test:coverage
```

location coverage file
```
ls coverage/
```