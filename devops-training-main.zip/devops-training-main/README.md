# devops-training-idn
Training DevOps IDN
## Rundown Training
- Introduction DevOps Concept
- Git : Version Control System
- Github : Source Code Management
- SonarQube: Testing & Code Analysis
- Docker : Containerization
- Jenkins : CI/CD Tools
- Prometheus : Monitoring System
- Grafana : Dashboard